// PortoConecta — script compartilhado entre as páginas

// Header + barra de progresso
const header = document.getElementById('siteHeader');
const progressBar = document.getElementById('progressBar');
function onScroll(){
  if (header) header.classList.toggle('scrolled', window.scrollY > 8);
  if (progressBar) {
    const h = document.documentElement;
    const scrollPct = (h.scrollTop) / (h.scrollHeight - h.clientHeight) * 100;
    progressBar.style.width = scrollPct + '%';
  }
}
document.addEventListener('scroll', onScroll, {passive:true});
onScroll();

// Menu mobile
const menuBtn = document.getElementById('menuBtn');
const navLinks = document.getElementById('navLinks');
const backdrop = document.getElementById('backdrop');
function closeMenu(){
  if (!navLinks) return;
  navLinks.classList.remove('open');
  menuBtn.classList.remove('open');
  backdrop.classList.remove('show');
  menuBtn.setAttribute('aria-expanded','false');
  document.body.style.overflow = '';
}
function toggleMenu(){
  const isOpen = navLinks.classList.toggle('open');
  menuBtn.classList.toggle('open', isOpen);
  backdrop.classList.toggle('show', isOpen);
  menuBtn.setAttribute('aria-expanded', String(isOpen));
  document.body.style.overflow = isOpen ? 'hidden' : '';
}
if (menuBtn && navLinks && backdrop) {
  menuBtn.addEventListener('click', toggleMenu);
  backdrop.addEventListener('click', closeMenu);
  navLinks.querySelectorAll('a').forEach(a => a.addEventListener('click', closeMenu));
}

// Accordions
function setupAccordion(triggerSelector, panelSelector){
  document.querySelectorAll(triggerSelector).forEach(trigger => {
    const panel = trigger.parentElement.querySelector(panelSelector);
    if (!panel) return;
    trigger.addEventListener('click', () => {
      const expanded = trigger.getAttribute('aria-expanded') === 'true';
      trigger.setAttribute('aria-expanded', String(!expanded));
      panel.style.maxHeight = expanded ? '0px' : panel.scrollHeight + 'px';
    });
  });
}
setupAccordion('.m-trigger', '.m-panel');
setupAccordion('.ev-trigger', '.ev-panel');

// Interest chips + form (apenas na home)
const interestButtons = document.querySelectorAll('.interest');
const selectedInterests = new Set();
interestButtons.forEach(btn => {
  btn.addEventListener('click', () => {
    btn.classList.toggle('active');
    if (btn.classList.contains('active')) selectedInterests.add(btn.textContent);
    else selectedInterests.delete(btn.textContent);
  });
});

// Modal de notícia
const NEWS_CONTENT = {
  'not1': {tag:'Infraestrutura', title:'Plano Nacional de Logística 2050 prevê R$ 1,225 trilhão em investimentos', body:[
    'O Plano Nacional de Logística (PNL) 2050 é o principal instrumento de planejamento do governo federal para o setor de transportes. Com previsão de investimentos que somam R$ 1,225 trilhão até 2050, o plano busca modernizar a infraestrutura brasileira e reduzir os gargalos que hoje custam ao país até R$ 300 bilhões por ano em perdas de produtividade.',
    'O Porto de Santos ocupa posição central nessa estratégia. Como maior porto da América Latina e responsável por cerca de 30% da balança comercial brasileira, qualquer investimento em rodovias, ferrovias e hidrovias ligadas ao complexo santista tem impacto direto na eficiência logística nacional.',
    'Para os jovens da Baixada Santista, isso significa oportunidades reais: obras de expansão, novos terminais e modernização de infraestrutura geram vagas em áreas que vão desde operação até engenharia, passando por administração e comércio exterior.'
  ]},
  'not2': {tag:'Futuro', title:'Entre Rota Bioceânica e trens de soja: o que vem pela frente em Santos', body:[
    'Duas grandes apostas de infraestrutura devem redefinir o fluxo de cargas do Porto de Santos na próxima década: a Rota Bioceânica, que conectará o oceano Atlântico ao Pacífico passando pela América do Sul, e a expansão das ferrovias voltadas ao escoamento da soja do Centro-Oeste.',
    'A Rota Bioceânica tem potencial para transformar Santos em um hub logístico ainda mais estratégico, encurtando distâncias entre o Brasil e mercados asiáticos. Já os corredores ferroviários de grãos podem aumentar significativamente a movimentação de commodities pelo porto.',
    'Para quem quer trabalhar no setor, entender esse contexto é fundamental — o porto do futuro vai demandar profissionais qualificados em logística internacional, gestão de armazéns e tecnologia da informação aplicada à operação portuária.'
  ]},
  'not3': {tag:'Economia', title:'Fosfatados nacionais ganham espaço com a dependência brasileira de fertilizantes', body:[
    'O Brasil é um dos maiores importadores de fertilizantes do mundo, dependendo de países como Rússia, China e Marrocos para abastecer sua agricultura. Diante das crises geopolíticas recentes, o governo tem apostado em ampliar a produção nacional de fosfatados, com reflexos diretos na cadeia logística.',
    'O Porto de Santos, principal porta de entrada e saída de insumos agrícolas, deve concentrar boa parte desse movimento — tanto na importação de matérias-primas quanto na exportação da produção nacional.',
    'Novas oportunidades surgem em áreas de armazenagem especializada, controle de qualidade, transporte multimodal e comércio exterior. É um setor em expansão que valoriza formação técnica e conhecimento em normas ambientais.'
  ]},
  'not4': {tag:'Energia', title:'Plano Safra libera crédito para energia própria no campo', body:[
    'O novo ciclo 2026/2027 do Plano Safra abriu linhas de crédito voltadas para a geração de energia renovável em propriedades rurais, reforçando a transição energética brasileira. Hoje, mais de 84% da matriz elétrica do país já vem de fontes limpas.',
    'A tendência tem impacto direto no setor portuário: terminais estão adotando guindastes elétricos, iluminação LED e sistemas de energia solar para reduzir emissões e custos operacionais.',
    'Para jovens interessados em sustentabilidade, esse movimento abre novas frentes de carreira em engenharia ambiental, gestão de energia e certificações verdes — áreas que devem crescer nos próximos anos.'
  ]},
  'not5': {tag:'Emprego', title:'Setor portuário deve abrir milhares de vagas nos próximos anos', body:[
    'A modernização de terminais, novos leilões de arrendamento e a expansão das operações do Porto de Santos devem gerar milhares de novas vagas nos próximos anos. Segundo dados da Prefeitura de Santos, em 2025 o município já registrou 38.738 vínculos empregatícios relacionados ao setor portuário.',
    'Boa parte dessas vagas não exige experiência prévia — pede apenas ensino médio completo, curso técnico e certificações específicas. Instituições como Cenep, Etec e Fatec oferecem os principais caminhos de qualificação na região.',
    'Para os jovens da Baixada Santista, o momento é oportuno: nunca houve tanta necessidade de mão de obra qualificada no setor, e nunca foi tão possível acessar essa qualificação gratuitamente.'
  ]},
  'not6': {tag:'Sustentabilidade', title:'COP30 coloca portos brasileiros no mapa da agenda climática', body:[
    'A COP30, realizada em Belém, colocou o setor portuário brasileiro no centro da agenda climática global. Descarbonização, eficiência energética e bem-estar dos trabalhadores foram temas destacados na conferência.',
    'O Brasil apresentou iniciativas como o programa "Saúde nos Portos", que integra o pilar social do ESG portuário, além de metas de redução de emissões nos principais complexos do país — incluindo Santos.',
    'A pauta ESG cria demanda por profissionais em áreas como gestão ambiental, compliance, relações institucionais e responsabilidade social. Confira nossa aba ESG para saber mais.'
  ]},
  'esg1': {tag:'Ambiental', title:'Portos brasileiros rumo à sustentabilidade', body:[
    'A conferência COP30 em Belém marcou um momento decisivo para o setor portuário brasileiro. Pela primeira vez, portos foram formalmente reconhecidos como elos estratégicos da agenda climática global, com responsabilidades específicas em descarbonização e eficiência energética.',
    'O Porto de Santos, como maior complexo da América Latina, tem papel central nesse movimento. Iniciativas como o programa "Saúde nos Portos" combinam bem-estar dos trabalhadores com práticas ambientais, mostrando que sustentabilidade é integral — envolve pessoas, meio ambiente e governança.',
    'Para os jovens que entram no setor, ESG deixa de ser um diferencial e se torna competência obrigatória. Formação em gestão ambiental, direito ambiental e compliance ganha cada vez mais espaço nas contratações.'
  ]},
  'esg2': {tag:'Energia', title:'Matriz elétrica brasileira já opera com mais de 84% de fontes limpas', body:[
    'A matriz elétrica brasileira é uma das mais limpas do mundo, com mais de 84% da energia vindo de fontes renováveis como hidrelétrica, eólica e solar. Essa característica cria vantagem competitiva para o país na chamada "economia verde".',
    'No setor portuário, essa transição se traduz em modernização: guindastes elétricos substituem equipamentos a diesel, painéis solares abastecem armazéns e frotas de veículos elétricos começam a operar em pátios de contêineres.',
    'A demanda por profissionais que entendem de energia renovável, eficiência energética e sistemas de automação cresce junto com essa transição.'
  ]},
  'esg3': {tag:'Governança', title:'PNL 2050: infraestrutura que reduz emissões', body:[
    'O Plano Nacional de Logística 2050 não é apenas um plano de investimentos: é também uma estratégia de descarbonização do transporte brasileiro. Ao priorizar modais mais eficientes como ferrovia, hidrovia e cabotagem, o PNL busca reduzir a dependência do rodoviário, que hoje domina a matriz nacional.',
    'Cada tonelada transportada por ferrovia emite cerca de 4 vezes menos CO2 que a mesma tonelada em caminhão. Ampliar a participação ferroviária no país tem impacto direto na meta climática nacional.',
    'Para o Porto de Santos, isso significa integração com corredores ferroviários maiores e investimento em terminais intermodais — abrindo vagas para engenheiros logísticos, planejadores e operadores.'
  ]},
  'esg4': {tag:'Social', title:'Saúde nos Portos: bem-estar do trabalhador em primeiro plano', body:[
    'O pilar "S" do ESG (Social) é frequentemente esquecido, mas tem ganhado protagonismo no setor portuário brasileiro. Programas de saúde ocupacional, prevenção de acidentes e apoio psicológico estão sendo estruturados em terminais e autoridades portuárias.',
    'O programa "Saúde nos Portos", apresentado na COP30, inclui atendimento médico regular, ações de prevenção de doenças ocupacionais e apoio à saúde mental dos trabalhadores portuários — categoria historicamente exposta a jornadas longas e ambiente estressante.',
    'A pauta social também envolve equidade: políticas específicas para saúde da mulher trabalhadora, apoio à maternidade e prevenção de assédio ganham espaço nos planos de sustentabilidade.'
  ]},
  'esg5': {tag:'Ambiental', title:'Dragagem sustentável e gestão de resíduos no cais', body:[
    'A dragagem — remoção de sedimentos do fundo do canal para permitir a entrada de navios maiores — é uma das operações portuárias com maior impacto ambiental. Novas técnicas e monitoramento constante buscam minimizar esse impacto.',
    'Terminais do Porto de Santos vêm adotando práticas como análise química dos sedimentos antes da remoção, destinação adequada dos materiais dragados e monitoramento contínuo da qualidade da água do canal.',
    'Além da dragagem, a gestão de resíduos operacionais — óleos, contaminantes, embalagens — segue normas rigorosas da ANTAQ e do órgão ambiental estadual, criando oportunidades para técnicos e engenheiros ambientais.'
  ]},
  'esg6': {tag:'Diversidade', title:'Diversidade e inclusão como parte da governança portuária', body:[
    'Autoridades portuárias e grandes terminais brasileiros vêm incluindo metas explícitas de diversidade — gênero, raça, pessoas com deficiência — em seus relatórios ESG e planos estratégicos.',
    'A Autoridade Portuária de Santos (APS) e terminais como DP World, BTP e Santos Brasil publicam anualmente dados de composição de sua força de trabalho e metas de aumento da participação feminina, especialmente em cargos operacionais e de liderança.',
    'Essa transparência é um avanço importante: torna possível medir progresso real e cobrar mudanças concretas. Para os jovens, sinaliza que o setor está aberto a perfis diversos.'
  ]},
  'por1': {tag:'Carreira', title:'Presença feminina em cargos operacionais cresce ano a ano', body:[
    'Segundo a 2ª Pesquisa sobre Equidade de Gênero no Setor Aquaviário da ANTAQ (2025), mulheres representam 17,8% da força de trabalho portuária brasileira, mas apenas 10% dos trabalhadores em cargos operacionais. Ainda que baixo, esse número vem crescendo ano a ano.',
    'Operadoras de empilhadeira, conferentes de carga, técnicas em manutenção e motoristas de RTG (Rubber Tyred Gantry) são funções que passam a receber cada vez mais mulheres — beneficiadas por programas de qualificação e políticas internas de diversidade dos terminais.',
    'A mudança acontece porque o setor descobriu que faltam operadores qualificados, e restringir o pool de talentos por gênero simplesmente não faz sentido econômico.'
  ]},
  'por2': {tag:'Saúde', title:'Programas de saúde ocupacional incluem trabalhadoras portuárias', body:[
    'O setor portuário brasileiro vem estruturando programas de saúde ocupacional que consideram as necessidades específicas das trabalhadoras. Historicamente pensados para uma força de trabalho majoritariamente masculina, esses programas agora incluem ações voltadas para saúde da mulher.',
    'Apoio à maternidade, prevenção e combate ao assédio, atendimento ginecológico regular e ergonomia adaptada compõem esses novos protocolos, adotados por autoridades portuárias e grandes terminais.',
    'A pauta faz parte do pilar Social do ESG portuário e ganha espaço nos relatórios de sustentabilidade das principais empresas do setor.'
  ]},
  'por3': {tag:'Formação', title:'Cursos técnicos ampliam captação de alunas', body:[
    'Instituições como Cenep, Etec e Fatec da Baixada Santista vêm registrando aumento na matrícula feminina em cursos historicamente masculinos: logística portuária, mecânica, automação e gestão portuária.',
    'O movimento é impulsionado por campanhas específicas de captação, bolsas dedicadas e mentorias com profissionais mulheres já atuantes no setor. O objetivo é criar um pipeline sustentável de talentos femininos para o mercado portuário.',
    'Para as jovens interessadas, o momento é único: nunca houve tanta oferta de vagas e tanto apoio institucional para entrar na área.'
  ]},
  'por4': {tag:'Reconhecimento', title:'Dia Internacional da Mulher no Setor Marítimo', body:[
    'Celebrado em 18 de maio pela Organização Marítima Internacional (IMO), o Dia Internacional da Mulher no Setor Marítimo reconhece a contribuição feminina ao shipping global e às atividades portuárias.',
    'A data é marcada por eventos em portos, universidades e empresas do setor no mundo inteiro. No Brasil, a Marinha Mercante, autoridades portuárias e a WISTA Brasil (Women\'s International Shipping & Trading Association) realizam palestras, mentorias e ações de conscientização.',
    'Mais que uma data comemorativa, a iniciativa busca visibilizar a presença feminina em um setor tradicionalmente masculino e inspirar novas gerações a considerar carreiras marítimo-portuárias.'
  ]}
};

const modalOverlay = document.getElementById('newsModal');
if (modalOverlay) {
  const modalTag = modalOverlay.querySelector('.modal-tag');
  const modalTitle = modalOverlay.querySelector('.modal-title');
  const modalBody = modalOverlay.querySelector('.modal-body');
  document.querySelectorAll('[data-news]').forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      const key = link.getAttribute('data-news');
      const data = NEWS_CONTENT[key];
      if (!data) return;
      modalTag.textContent = data.tag;
      modalTitle.textContent = data.title;
      modalBody.innerHTML = data.body.map(p => `<p>${p}</p>`).join('');
      modalOverlay.classList.add('show');
      document.body.style.overflow = 'hidden';
    });
  });
  modalOverlay.querySelector('.modal-close').addEventListener('click', () => {
    modalOverlay.classList.remove('show');
    document.body.style.overflow = '';
  });
  modalOverlay.addEventListener('click', (e) => {
    if (e.target === modalOverlay) {
      modalOverlay.classList.remove('show');
      document.body.style.overflow = '';
    }
  });
}

const form = document.getElementById('signupForm');
const confirmMsg = document.getElementById('confirmMsg');
if (form) {
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const email = document.getElementById('emailInput').value;
    const areas = selectedInterests.size
      ? Array.from(selectedInterests).join(', ')
      : 'todas as áreas';
    confirmMsg.textContent = `Prontinho: quando sair algo em ${areas}, avisamos em ${email}.`;
    confirmMsg.classList.add('show');
    form.reset();
  });
}
